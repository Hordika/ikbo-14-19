package laba;
public class Laba {
    public static void main(String[] args) {
        int[] Numbers;
        Numbers = new int[10]; 
        {
		final int max = 100; 
                for(int i=0;i<10;i++){
                    final int rnd = rnd(max);
                    Numbers[i]= rnd;
                    System.out.print("\nСлучайное целое число: " + rnd);
                }
        }
        
        System.out.print("\nСортировка:");
        
        int zam;
        for(int x=0;x<10;x++){//для числа проверок
        for(int i=0;i<9;i++){
            int c=i;
            if((Numbers[c]>=Numbers[c+1])&&(c!=10)){
                zam=Numbers[c+1];
                Numbers[c+1]=Numbers[c];
                Numbers[c]=zam;
                c++;
            }
        }
        }
        for (int i=0;i<10;i++){
                    System.out.print("\nСлучайное целое число: " + Numbers[i]);
                }
    }
     public static int rnd(int max)
	{
		return (int) (Math.random() * ++max);
	}
}
