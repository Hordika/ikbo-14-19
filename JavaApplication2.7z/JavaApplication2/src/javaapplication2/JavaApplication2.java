package javaapplication2;
public class JavaApplication2 {

public static void main(String[] args) {
    sobaka sobaka = new sobaka(15, "Pesa");
        System.out.println("Данные собаки:");
        System.out.println("age = " + sobaka.getAge() + "\nname is " + sobaka.getName());
        
        myach myach = new myach(6, "red");
        System.out.println("\nДанные мяча:");
        System.out.println("size = " + myach.getSize() + "\ncolor is " + myach.getColor());
        
        kniga kniga = new kniga(257, "Гроза");
        System.out.println("\nДанные книги:");
        System.out.println("page = " + kniga.getPage() + "\nname is " + kniga.getName());
    }
    
}
