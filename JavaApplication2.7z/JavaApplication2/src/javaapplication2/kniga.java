package javaapplication2;
public class kniga {
   private final int page;
    private final String name;
    
    kniga (int page, String name){
        this.page = page;
        this.name = name;
    }
    
    public String getName(){
        return this.name;
    }
    public int getPage(){
        return this.page;
    } 
}
