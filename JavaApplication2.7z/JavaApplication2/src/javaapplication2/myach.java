package javaapplication2;
public class myach {
    private final String color;
    private final int numSize;
    
    myach (int numSize, String color){
        this.color = color;
        this.numSize = numSize;
    }
    
    public String getColor(){
        return this.color;
    }
    
    public int getSize(){
        return this.numSize;
    }
}
